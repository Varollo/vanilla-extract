# Version 0 (Unfinished Release)

## **Unfinished Release** (v0) [30% Progress]

✅ New
* stone/deepslate to cobblestone/cobbled deepslate (stonecutter)
* craftable cobweb
* chainmail armor recipe
* various colormixing recipes for dyes
* (dead) coral block recipe
* dry coral (furnace)
* exchange coral/coral fans
* experience bottle recipe
* crush glowberries to glowstone
* grass recipe
* horse armor recipes
* dry rotten flesh to leather (furnace)
* emtpy a filled map
* saddle recipe
* spectral arrow recipe
* trident recipe
* wool to string
* mushroom block recipes
* warped wart block recipe
* shortcuts for (trapped) chests, dispenser, ladder, repeater, spectral arrow
* reverse for amethyst/dripstone/honeycomb/purpur/snow block, cobweb, warped/nether wart block, glowstone, blue/packed ice, tnt/chest/furnace/hopper minecart, red/brown mushroom block, (red) nether bricks (crafting table/stonecutter), block of quartz

🔁 Changed
* Beacon recipe with any colored glass and crying obsidian
* bell with any plank type


## **Unfinished Release** (v0.1) [40% Progress]

✅ New
* added slab to block recipes for acacia/crimson/dark oak/jungle/mangrove/oak/spruce/warped planks, (polished) andesite/diorite/granite, blackstone, (mud/endstone/nether/prismarine/red nether/stone) bricks, cobbled deepslate, cobblestone, (waxed) (exposed/oxidized/weathered) cut copper, (cut/smooth) (red) sandstone, (dark) prismarine, deepslate bricks/tiles, mossy cobblestone/stone bricks, polished blackstone/deepslate bricks, purpur, (smooth) quartz, (smooth) stone
* trapped chest shortcut and chest shortcut now work combined

🔁 Changed
* spectral arrow recipe (with glowberries)  now results in 2 spectral arrows to match vanilla

❌ Removed
* removed spectral arrow shortcuts


## **Unfinished Release** (v0.2) [60% Progress]

✅ New
* added chest boat shortcuts (similar to minecart shortcuts)
* nametag recipe
* infuse obsidian with ghast tears to get crying obsidian
* even more recipes grouped together with vanilla recipes in the recipe book (dispenser/repeater shortcut, bed redye, dyes from colormixing, (trapped) chest (shortcut))

🔁 Changed
* bugfix: kevr:slabtoblock_cut_sandstone required cut sandstone, instead of cut sandstone slabs


## **Unfinished Release** (v0.3) [70% Progress]

✅ New
* added shapeless jack o'lantern recipe using any of the following light emitting items: any candle, glow berries, glowstone, glowstone (dust), sealantern, (soul) lantern, (redstone/soul) torch
* you can now convert infested (cracked/mossy/chiseled) stone bricks, infested cobblestone, infested deepslate and infested stone to regular (cracked/mossy/chiseled) stone bricks, cobblestone, deepslate and infested stone by simply putting it in a stonecutter


## **Unfinished Release - Recipe Book Unlocked!** (v0.4) [75% Progress]

✅ New
* slab to block recipes are now unlocked and shown in the recipe book, if you have the type of slab needed
* shortcut recipes are now unlocked and shown in the recipe book, if craft/obtain the item the shortcut is for or obtain the recipe for that item
* added slab to block recipe for polished blackstone

🔁 Changed
* changed bell recipe to require an additional gold block, because of feedback by [@Jasdan](https://www.planetminecraft.com/member/jasdan/)
* #kevr:light_emitting (used for crafting jack o'lantern) now includes frog light variants
* added as/at comment to functions
* bugfix: kevr:slabtoblock_smooth_stone resulted in smooth stone slabs, instead of smooth stone